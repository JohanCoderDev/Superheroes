package com.movil.superhero

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
class Superhero(val heroName:String, val alterEgoText:String, val bioText:String, val ratingBar:Float) : Parcelable