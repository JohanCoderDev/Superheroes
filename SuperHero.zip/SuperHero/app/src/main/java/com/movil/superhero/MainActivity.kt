package com.movil.superhero

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.movil.superhero.databinding.ActivityMainBinding
import org.w3c.dom.Text



class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)



        binding.botonGuardar.setOnClickListener{
            val heroName = binding.nombreSuperhero.text.toString()
            val alterEgoText = binding.rango.text.toString()
            val bioText = binding.textoDescripcion.text.toString()
            val ratingBar = binding.Poder.rating
            val hero = Superhero(heroName, alterEgoText, bioText, ratingBar)
            openDetailActivity(hero)
        }

        binding.botonGuardar2.setOnClickListener{
            openMainActivity2()
        }

    }

    private fun openMainActivity2() {
        startActivity(intent)
    }

    private fun openDetailActivity(superheros: Superhero){
        val intent = Intent(this, DetailActivity::class.java)
        intent.putExtra(DetailActivity.SUPERHERO_KEY, superheros)
        startActivity(intent)
    }
}