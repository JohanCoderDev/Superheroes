package com.movil.superhero

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.movil.superhero.databinding.ActivityDetailBinding

class DetailActivity : AppCompatActivity() {
    //Definiendo constantes o metodos estaticos
    companion object{
        const val SUPERHERO_KEY = "superhero_name"

    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)
        //La variable bundle recibe todo el paquete de variables que llegan de mainActivity
        //Las variables que llegan no pueden ser nulas para eso se utilizan los "!!"
        val bundle:Bundle = intent.extras!!
        val superhero = bundle.getParcelable<Superhero>(SUPERHERO_KEY)!!
        binding.superhero = superhero

        binding.regresarDetail.setOnClickListener{
            val nombreSuperhero = ""
            val rango = ""
            val textoDescripcion = ""
            val Poder = 0f

            openMainActivity()
        }
    }

    private fun openMainActivity() {
        startActivity(intent)
    }
}