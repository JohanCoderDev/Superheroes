package com.movil.superhero


import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.movil.superhero.databinding.ActivityMain2Binding


class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityMain2Binding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.regresar.setOnClickListener{
            openMainActivity()
        }
    }
    private fun openMainActivity() {
        startActivity(intent)
    }
    }





